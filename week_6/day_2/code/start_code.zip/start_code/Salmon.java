public class Salmon {

}