var initialize = function(){
  var container = document.getElementById('map');
  var chicagoButton = document.querySelector('#chicago-button');
  var whereAmIButton = document.querySelector('#geo-button');

  var center = { lat: 40.712784, lng: -74.005941 };

  var map = new Map(container, center, 10);
  // map.addMarker(center);
  map.addClickEvent();
  map.addInfoWindow(center, "Start spreadin' the news, I'm leavin' today <br>I want to be a part of it <br> <b>New York, New York</b>");

  var goToChicago = function(){
    var chicago = { lat: 41.878114, lng: -87.629798 };
    map.googleMap.setCenter(chicago);
    map.addInfoWindow(chicago, "<h3>Chicago</h3>"); 
  }

  var findLocation = function(){
    map.geoLocate();
  }

  chicagoButton.onclick = goToChicago;
  whereAmIButton.onclick = findLocation;
}

window.onload = initialize;